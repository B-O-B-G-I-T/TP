public interface EstComparable {
    
    int compareA(Object o);
}
